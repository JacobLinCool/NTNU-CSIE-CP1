// Copyright (c) JacobLinCool
#include <stdint.h>
#include <inttypes.h>
#include <stddef.h>

int32_t big_two_sort(int8_t cards[]);

// Any application that can be written in JavaScript, will eventually be written in JavaScript.
